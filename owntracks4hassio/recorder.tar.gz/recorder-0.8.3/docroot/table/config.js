config = {

  /* Titles of columns in the table. May be "". */
  column_titles: {
	face:		"",
  	topic:		"Topic",
	fulldate:	"Date/Time",
	name:		"Name",
	user:		"User",
	batt:		"Battery",
	tid:		"TID",
	cc:		"CC",
	addr:		"Address",
	vel:		"Vel",
	cog:		"CoG"
  }
};
