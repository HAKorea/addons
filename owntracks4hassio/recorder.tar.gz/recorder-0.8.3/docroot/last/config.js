
/*
 * Optionally rename the topic in the location popup on the map
 */

var renames = {
	'jjolie/phone' : 'Jane Jolie',
	'john/android' : "John Smith",

};
